#!/bin/sh
xcursorgen dnd-move.cursor dnd-move
