#!/bin/sh
xcursorgen zoom-in.cursor zoom-in
