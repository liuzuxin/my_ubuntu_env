#!/bin/sh
xcursorgen bottom_left_corner.in bottom_left_corner
