#!/bin/sh
xcursorgen top_left_corner.in top_left_corner
