#!/bin/sh
xcursorgen right_side.in right_side
