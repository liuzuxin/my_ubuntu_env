#!/bin/sh
xcursorgen left_ptr_watch.cursor left_ptr_watch

cp    left_ptr_watch	08e8e1c95fe2fc01f976f1e063a24ccd
cp    left_ptr_watch	3ecb610c1bf2410f44200f48c40d3599
