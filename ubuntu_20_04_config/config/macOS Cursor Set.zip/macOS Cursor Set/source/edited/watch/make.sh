#!/bin/sh
xcursorgen watch.cursor watch
