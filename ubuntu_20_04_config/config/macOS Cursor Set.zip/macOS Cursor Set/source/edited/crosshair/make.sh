#!/bin/sh
xcursorgen crosshair.in crosshair
