#!/bin/sh
xcursorgen xterm.cursor xterm
