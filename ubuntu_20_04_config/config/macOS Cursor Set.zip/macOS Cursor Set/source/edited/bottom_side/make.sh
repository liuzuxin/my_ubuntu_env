#!/bin/sh
xcursorgen bottom_side.in bottom_side
