#!/bin/sh
xcursorgen crossed_circle.cursor crossed_circle

cp    crossed_circle	03b6e0fcb3499374a867c041f52298f0

