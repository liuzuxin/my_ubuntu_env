#!/bin/sh
xcursorgen bottom_right_corner.in bottom_right_corner
