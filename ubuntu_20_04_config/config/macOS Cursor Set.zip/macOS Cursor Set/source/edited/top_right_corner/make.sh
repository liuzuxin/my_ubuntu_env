#!/bin/sh
xcursorgen top_right_corner.in top_right_corner
