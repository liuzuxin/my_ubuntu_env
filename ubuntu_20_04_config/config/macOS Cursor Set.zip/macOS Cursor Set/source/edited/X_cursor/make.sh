#!/bin/sh
xcursorgen X_cursor.in X_cursor

cp    X_cursor			pirate

